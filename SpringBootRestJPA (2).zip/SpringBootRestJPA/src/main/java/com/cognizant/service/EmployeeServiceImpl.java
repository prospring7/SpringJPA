package com.cognizant.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.entity.Employee;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	
	static List<Employee> empList=null;
	
	static{
		empList=new ArrayList<Employee>();
		
		Employee e1=new Employee();
		e1.setEmpId(101);
		e1.setEmpName("sabbir poonawala");
		e1.setEmpSalary(34000);
		e1.setEmpDesignation("Trainer");
		
		Employee e2=new Employee();
		e2.setEmpId(102);
		e2.setEmpName("Amit Kumar");
		e2.setEmpSalary(24000);
		e2.setEmpDesignation("Developer");
		
		Employee e3=new Employee();
		e3.setEmpId(103);
		e3.setEmpName("Chirag Desai");
		e3.setEmpSalary(39000);
		e3.setEmpDesignation("Accountant");
		
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		
	}
	

	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return empList;
	}


	public Employee getEmployee(int empId) {
		// TODO Auto-generated method stub
		Employee employee=new Employee();
		for(Employee emp:empList){
			if(emp.getEmpId()==empId){
				employee=emp;
			}
		}
		return employee;
	}


	public boolean persistEmployee(Employee employee) {
		// TODO Auto-generated method stub
		Employee emp=getEmployee(employee.getEmpId());
		if(employee.getEmpId()==emp.getEmpId()){
			return false;
		}else{
			return empList.add(employee);

		}
		
		
	}


	public boolean updateEmployeeSalary(int empId, double newSalary) {
		// TODO Auto-generated method stub
		for(Employee emp:empList){
			if(emp.getEmpId()==empId){
				double oldSalary=emp.getEmpSalary();
				
				emp.setEmpSalary(newSalary);
				
				if(oldSalary!=newSalary)
					return true;
				
			}
		}
		return false;
	}


	public boolean deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		boolean flag=false;
		for(Iterator<Employee> iterator=empList.iterator();iterator.hasNext();){
			Employee emp=iterator.next();
			if(emp.getEmpId()==empId){
				iterator.remove();
				flag=true;
			}
		}
		return flag;
	}

}
